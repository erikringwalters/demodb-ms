package csumbcapstonegroup22spring2019.demodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemodbApplication.class, args);
	}

}
